
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author abdussalam
 */
public class Model {
    
    
    public int registerationFunciton(User user) throws SQLException {
        Statement stmt = ConnectionDB.con.createStatement();
        String sql2 ="";
        return stmt.executeUpdate(sql2);
    }
    public int main() {

        return 0;
    }

}
