
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 * To be able to understand this code please watch this video first
 * https://www.youtube.com/watch?v=w0LwGqffUkg after that  I sure  you will be able to
 * understand it very quickly -_*
 */
/**
 * @author abdussalam
 */
public class BankerAlgoClass {

    public int NPROCESSES = 5;
    public int NRESOURCES = 3;
    public int[] available = {10, 5, 7};
    public int[] work = {10, 5, 7};

    public int[][] maximum = new int[NPROCESSES][NRESOURCES];
    public int[][] allocation = new int[NPROCESSES][NRESOURCES];
    public int[][] need = new int[NPROCESSES][NRESOURCES];
    boolean[] flag = new boolean[NPROCESSES];

    public int[] availableCopy = {10, 5, 7};
    public int[][] maximumCopy = new int[NPROCESSES][NRESOURCES];
    public int[][] allocationCopy = new int[NPROCESSES][NRESOURCES];
    public int[][] needCopy = new int[NPROCESSES][NRESOURCES];
    Scanner in = new Scanner(System.in);

    void initialAlloc(String fileName) throws FileNotFoundException, IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            int i = 0;
            while ((line = br.readLine()) != null) {
                String[] ch = (line.split(","));
                for (int j = 0; j < ch.length; j++) {
                    allocation[i][j] = Integer.parseInt(String.valueOf(ch[j]));
                }
                i++;
            }
        } catch (Exception e) {
            System.out.println(fileName + " NOT EXIST  !!!");
        }
    }

    void print() {
        for (int k = 0; k < 5; k++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(need[k][j] + " ");
            }
            System.out.println();
        }
    }

    void input(String fileName) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            int i = 0;
            while ((line = br.readLine()) != null) {
                String[] ch = (line.split(","));
                for (int j = 0; j < ch.length; j++) {
                    maximum[i][j] = Integer.parseInt(String.valueOf(ch[j]));
                }
                i++;
            }
        } catch (Exception e) {
            System.out.println(fileName + " NOT EXIST  !!!");
        }
        initialAlloc("Allocation.txt"); // InitialAllocation matreix 
        // calculate need matrix
        for (int i = 0; i < NPROCESSES; i++) {
            for (int j = 0; j < NRESOURCES; j++) {
                need[i][j] = maximum[i][j] - allocation[i][j]; // need = max - alloc 
            }
        }
    }

    void algorithm() {
        copy(); //keep copy to return data  if it's not safe
        work = copyArray(available);
        if (isSafe()) {
            while (true) {
                System.out.println("1- State  Command\n2- Make a Request\n3- Release\n4-Quit\n");
                int choice = in.nextInt();
                switch (choice) {
                    case 1:
                        printStatus();
                        break;
                    case 2:
                        System.out.println("Enter the Process Number and the Request");
                        int processNumber = in.nextInt();
                        int[] request = new int[NRESOURCES];
                        for (int i = 0; i < NRESOURCES; i++) {
                            request[i] = in.nextInt();
                        }
                        boolean isDonated = false;
                        for (int i = 0; i < NRESOURCES; i++) { // check request with need  matrixSSS

                            if (need[processNumber][i] < request[i]) {
                                System.out.println("the Request is > greater than need , so this request will be donated");
                                isDonated = true;
                                break;
                            }
                        }
                        if (isDonated) {
                            continue;
                        }
                        for (int i = 0; i < NRESOURCES; i++) { // add request to alloc matrix
                            allocation[processNumber][i] += request[i];
                            need[processNumber][i] -= request[i];
                        }
                        for (int i = 0; i < NRESOURCES; i++) { // sub request from available matrix
                            available[i] -= request[i];
                        }
                        work = copyArray(available);
                        if (isSafe()) {
                            availableCopy = copyArray(available);
                            System.out.println("Your Request Done and is Safe");
                            copy();
                            continue;
                        } else {
                            copyRev();
                            System.out.println("Your Request Rejected !! , isn't safe , Try another Request");
                            continue;
                        }
                    case 3:
                        System.out.println("Enter the Process Number and the Release Values");
                        int pnum = in.nextInt();
                        int[] release = new int[NRESOURCES];
                        for (int i = 0; i < NRESOURCES; i++) {
                            release[i] = in.nextInt();
                        }
                        boolean isLess = false;
                        for (int i = 0; i < NRESOURCES; i++) {
                            available[i] += release[i];
                            availableCopy[i] += release[i];
                            if (allocationCopy[pnum][i] > 0) {
                                allocationCopy[pnum][i] -= release[i];
                                if (allocationCopy[pnum][i] < 0) {
                                    isLess = true;
                                    allocationCopy[pnum][i] = 0;
                                }
                            }
                            if (allocation[pnum][i] > 0) {
                                allocation[pnum][i] -= release[i];
                                if (allocation[pnum][i] < 0) {
                                    allocation[pnum][i] = 0;
                                }
                            }
                        }
                        if (isLess) {
                            System.out.println("The release greater than allocation ,");
                            System.out.println("allocation will be   = 0");
                        } else {
                            System.out.println("The system Finished Release Process");
                        }
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Wrong Choice");
                        continue;
                }
            }
        } else {
            System.out.println("the current state NOT Safe ");
        }
    }
    int[] copyArray(int[] arr) {
        int[] newArr = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            newArr[i] = arr[i];
        }
        return newArr;
    }

    void copy() {
        for (int i = 0; i < available.length; i++) {
            availableCopy[i] = available[i];
        }
        for (int i = 0; i < NPROCESSES; i++) {
            for (int j = 0; j < NRESOURCES; j++) {
                allocationCopy[i][j] = allocation[i][j];
            }
        }
        for (int i = 0; i < NPROCESSES; i++) {
            for (int j = 0; j < NRESOURCES; j++) {
                needCopy[i][j] = need[i][j];
            }
        }
    }

    void copyRev() {
        for (int i = 0; i < available.length; i++) {
            available[i] = availableCopy[i];
        }

        for (int i = 0; i < NPROCESSES; i++) {
            for (int j = 0; j < NRESOURCES; j++) {
                allocation[i][j] = allocationCopy[i][j];
            }
        }
        for (int i = 0; i < NPROCESSES; i++) {
            for (int j = 0; j < NRESOURCES; j++) {
                need[i][j] = needCopy[i][j];
            }
        }
    }

    private boolean isSafe() {
        for (int i = 0; i < NPROCESSES; i++) {
            flag[i] = false;
        }
        int counter = 0;
        while (!isReady()) {
            if (counter == NPROCESSES) {
                return false;
            }
            for (int i = 0; i < NPROCESSES; i++) {
                if (isLess(i)) {
                    if (flag[i] == false) {
                        for (int k = 0; k < NRESOURCES; k++) {// update avalilabel matrix
                            work[k] = work[k] + allocation[i][k];
                        }
                        flag[i] = true;
                    }
                }
            }
            counter++;
        }
        return true;
    }

    public boolean isLess(int index) {
        for (int j = 0; j < NRESOURCES; j++) {
            if ((need[index][j] > work[j])) {
                return false;
            }
        }
        return true;
    }

    private boolean isReady() {
        for (int i = 0; i < NPROCESSES; i++) {
            if (flag[i] == false) {
                return false;
            }
        }
        return true;
    }

    private void printStatus() {
        System.out.println("\tAllcation Matrix");

        for (int i = 0; i < NPROCESSES; i++) {
            for (int j = 0; j < NRESOURCES; j++) {
                System.out.print(allocation[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("\tNeed Matrix");

        for (int i = 0; i < NPROCESSES; i++) {
            for (int j = 0; j < NRESOURCES; j++) {
                System.out.print(need[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("\tAvailable Resources");
        for (int b : available) {
            System.out.print(b + " ");
        }
        System.out.println();

    }

}
